Component({
    options: {
        styleIsolation: 'apply-shared'
    }
})