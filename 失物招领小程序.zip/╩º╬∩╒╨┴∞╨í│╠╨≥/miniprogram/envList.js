const envList = [{"envId":"creator-xcq6k","alias":"creator"}]
const isMac = true
module.exports = {
    envList,
    isMac
}